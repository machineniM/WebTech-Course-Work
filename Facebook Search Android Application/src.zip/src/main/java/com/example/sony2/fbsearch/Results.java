package com.example.sony2.fbsearch;

import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Results extends AppCompatActivity  implements TabLayout.OnTabSelectedListener {

    public static HashMap<String, JSONObject> resultsData = new HashMap<String, JSONObject>();
    public static HashMap<String, Object> detailsData = new HashMap<String, Object>();

    List<ProfileData> profileDataArray = new ArrayList<ProfileData>();
    public static String previous_Url = "";
    public static String next_Url = "";
    public static String profileType = "user";
    public static List<ProfileData> profileDataFavArray = new ArrayList<ProfileData>();
    public static JSONObject detailsDataResponse=new JSONObject();
    public Boolean isFavResults=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        profileType="user";
        int tabsLayout = R.id.tabs;
        TabLayout tabLayout = (TabLayout) findViewById(tabsLayout);
        int toolBarId = R.id.results_toolbar;
        Toolbar toolbar = (Toolbar) findViewById(toolBarId);
        Intent intent = getIntent();

        if (null != tabLayout) {
            int position = tabLayout.getSelectedTabPosition();
            tabLayout.addOnTabSelectedListener(this);
        }

        buildTheFavListView();

        if(null!=intent) {
            String searchKeyword = intent.getStringExtra("SearchKeyWord");
            String profileTypeIntent = intent.getStringExtra("profileType");
            String toolBarTitle = intent.getStringExtra("ToolBarTitle");
            Boolean isCallFromDetails = intent.getBooleanExtra("isCallFromDetails", false);
            if (null != getSupportActionBar()) {
                String title = null != toolBarTitle && !"".equals(toolBarTitle) ? toolBarTitle : "Results";
                isFavResults = "Favorites".equals(title) ? true : false;
                getSupportActionBar().setTitle(title);
            }
            profileType = null != profileTypeIntent && !"".equals(profileTypeIntent) ? profileTypeIntent : "user";
            int tabIndex = 0;
            switch (profileType) {
                case "page":
                    tabIndex = 1;
                    break;
                case "event":
                    tabIndex = 2;
                    break;
                case "place":
                    tabIndex = 3;
                    break;
                case "group":
                    tabIndex = 4;
                    break;
            }
            TabLayout.Tab tab = tabLayout.getTabAt(tabIndex);
            tab.select();
            if (null != searchKeyword && !"".equals(searchKeyword)) {
                String profileTypeArray[] = {"user", "page", "event", "place", "group"};
                for (String profileType : profileTypeArray) {
                    String response = intent.getStringExtra(profileType);
                    try {
                        // JSONObject json = (JSONObject) (new JSONTokener(response).nextValue());
                        JSONObject json = new JSONObject(response);
                        resultsData.put(profileType, json);
                    } catch (Exception e) {
                        System.out.println("Exception" + e);
                    }
                    System.out.println("ResultsData" + resultsData);
                }
                JSONObject userTypeResponse = getProfileTypeResponse(profileType);
                dataToBeDisplayedList(userTypeResponse, true);
            } else if (null != isCallFromDetails && isCallFromDetails) {
                String title = getSupportActionBar().getTitle().toString();
                if ("Favorites".equals(title)) {
                    callToConstructView(profileType);
                }
                else {
                    JSONObject userTypeResponse = getProfileTypeResponse(profileType);
                    dataToBeDisplayedList(userTypeResponse, true);
                }
            }
            else{
                callToConstructView(profileType);
            }

        }
//        if(null!=getSupportActionBar().getTitle() && !"Favorites".equals(getSupportActionBar().getTitle())){
            AppBarLayout.LayoutParams layoutParams = (AppBarLayout.LayoutParams) toolbar.getLayoutParams();
            layoutParams.height = 0;
            toolbar.setLayoutParams(layoutParams);
            toolbar.requestLayout();

//        }

    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        int position = tab.getPosition();
        String text = tab.getText().toString();
        String userType = "";
        if (null != text && "" != text) {
            userType = text.toLowerCase().substring(0, text.length() - 1);
        }
        if ("" != userType) {
            String title = getSupportActionBar().getTitle().toString();
            if ("Favorites".equals(title)) {
                callToConstructView(userType);
            } else {
                JSONObject userTypeResponse = getProfileTypeResponse(userType);
                profileType = userType;
                dataToBeDisplayedList(userTypeResponse, true);
            }
        }
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {
        //This will be called 1st when you select a tab or swipe using viewpager
    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {
        //This will be called only when you select the already selected tab(Ex: selecting 3rd tab again and again)
    }

    public JSONObject getProfileTypeResponse(String type) {
        JSONObject response = null;
        if (null != type) {
            response = resultsData.get(type);
        }
        return response;
    }


    public void dataToBeDisplayedList(JSONObject response, Boolean isSet) {
        List<ProfileData> profileData = new ArrayList<ProfileData>();
        profileDataArray.clear();
        SharedPreferences preferences = getPreferences();
        String previousUrl = null;
        String nextUrl = null;
        try {
            if (null != response) {
                JSONArray responseData = (JSONArray) response.get("data");
                int length = 0;
                if (null != responseData) {
                    length = responseData.length();
                }
                if (length == 0) {
                    profileDataArray = profileData;
                    /*if (isSet) {
                        callToCustomAdapter();
                    }
                    return;*/
                }

                JSONObject pagingObj = null;
                if (response.has("paging")) {
                    pagingObj = (JSONObject) response.get("paging");
                }
                if (null != pagingObj && pagingObj.has("next")) {
                    nextUrl = null != pagingObj.get("next") ? pagingObj.get("next").toString() : null;
                }
                if (null != pagingObj && pagingObj.has("previous")) {
                    previousUrl = null != pagingObj.get("previous") ? pagingObj.get("previous").toString() : null;

                }
                JSONArray jsonArray = (JSONArray) response.get("data");
                for (int i = 0; i < length; i++) {
                    String icon = "";
                    JSONObject record = (JSONObject) jsonArray.get(i);
                    JSONObject picData = (JSONObject) record.get("picture");
                    if (null != picData && picData.has("data")) {
                        JSONObject picDataObj = (JSONObject) picData.get("data");
                        icon = picDataObj.get("url").toString();
                    }

                    String profileId = (record.get("id")).toString();
                    String profileName = record.get("name").toString();
                    Boolean isFav = false;
                    if (null != preferences) {
                        isFav = preferences.contains(profileId) ? true : false;
                    }
                    ProfileData pd = new ProfileData(profileId, profileName, icon, profileType, isFav);
                    profileDataArray.add(pd);
                }
            }
            previous_Url = previousUrl;
            next_Url = nextUrl;

            if (isSet) {
                callToCustomAdapter();
            }
        } catch (Exception e) {
            System.out.println("Exception" + e);
        }


            /*

             */
    }

    public void callToCustomAdapter() {
        Button previousButton = (Button) findViewById(R.id.previous_button);
        Button nextButton = (Button) findViewById(R.id.next_button);
        if (null != previousButton) {
            if (null != previous_Url && "" != previous_Url) {
                previousButton.setEnabled(true);
            } else {
                previousButton.setEnabled(false);

            }
        }
        if (null != nextButton) {
            if (null != next_Url && "" != next_Url) {
                nextButton.setEnabled(true);
            } else {
                nextButton.setEnabled(false);
            }
        }
        CustomList adapter = new CustomList(profileDataArray);
        ListView listView = (ListView) findViewById(R.id.list_item_view);
        listView.setAdapter(adapter);

    }

    public void onPreviousButtonClick(View view) {
        if (null != previous_Url && "" != previous_Url) {
            new RequestServerDataForPrevDetails().execute("true", previous_Url);
        }

    }


    public void onNextButtonClick(View view) {
        if (null != next_Url && "" != next_Url) {
            new RequestServerDataForPrevDetails().execute("true", next_Url);
        }
    }

    /*
    To set the preference
     */
    public SharedPreferences getPreferences() {
        Context context = this.getApplicationContext();
        SharedPreferences sharedPref = this.getSharedPreferences("LocalStorageFav", context.MODE_PRIVATE);
        return sharedPref;
    }













    /*
    Inner Class
     */

    /*inner class*/
    public class RequestServerDataForPrevDetails extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                String nextPrev = params[0];
                String link = "http://sample-env.ittyk9qerj.us-west-2.elasticbeanstalk.com/FBSearch.php";
                if (null != nextPrev && nextPrev == "true") {
                    link += "?keyword=null&searchtype=null&nextPreviousIdentifier=" + Uri.encode(params[1]);
                }
                URL url = new URL(link);
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(link));
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                String response = client.execute(request, responseHandler);
                JSONObject json = new JSONObject(response);
                dataToBeDisplayedList(json, false);
                return "";

            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            callToCustomAdapter();
        }
    }

    /*
    Inner Class
     */

    public class CustomList extends ArrayAdapter<ProfileData> {

        /*private final Activity context;
        private final String[] web;
        private final Integer[] imageId;*/
        public CustomList(List<ProfileData> profileDataArray) {
            super(Results.this, R.layout.layout_results_view, profileDataArray);
        }

        @Override
        public View getView(final int position, View view, ViewGroup parent) {
            try {
                if (view == null) {
                    //view = Results.this.getLayoutInflater().inflate(R.layout.layout_results_view, parent, false);
                    view = Results.this.getLayoutInflater().inflate(R.layout.layout_results_view, null, true);
                }

//                final ProfileData concurrentProfileData =favTabs? profileDataFavArray.get(position):profileDataArray.get(position);
                final ProfileData concurrentProfileData = profileDataArray.get(position);

                TextView txtTitle = (TextView) view.findViewById(R.id.item_name);
                final ImageButton imgFavButton = (ImageButton) view.findViewById(R.id.item_fav);
                Boolean isFav = false;
                if (null != imgFavButton) {
                    isFav = concurrentProfileData.getFav();
                    if (isFav) {
                        imgFavButton.setImageResource(R.mipmap.ic_favoriteon);
                    } else {
                        imgFavButton.setImageResource(R.mipmap.ic_favoriteoff);
                    }
                    imgFavButton.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            ListView listView = (ListView) findViewById(R.id.list_item_view);
                            Boolean favTabs = (null != getSupportActionBar() && "Favorites".equals(getSupportActionBar().getTitle().toString())) ? true : false;
                            Boolean fav = concurrentProfileData.getFav();
                            SharedPreferences.Editor editor = getPreferences().edit();
                            TabLayout tabsLay = (TabLayout) findViewById(R.id.tabs);
                            String type = "user";
                            if (null != tabsLay) {
                                TabLayout.Tab tab = tabsLay.getTabAt(tabsLay.getSelectedTabPosition());
                                type = (tab.getText().toString()).toLowerCase().substring(0, (tab.getText().toString()).length() - 1);

                            }
                            if (!fav) {
                                concurrentProfileData.setFav(true);
                                try {
                                    JSONObject jsonObjFav = new JSONObject();
                                    jsonObjFav.put("profileId", concurrentProfileData.getProfileId());
                                    jsonObjFav.put("profileName", concurrentProfileData.getProfileName());
                                    jsonObjFav.put("profilePicture", concurrentProfileData.getImageUrl());
                                    jsonObjFav.put("profileType", type);
                                    ProfileData pd = new ProfileData(concurrentProfileData.getProfileId(), concurrentProfileData.getProfileName(), concurrentProfileData.getImageUrl(), type, true);
                                    imgFavButton.setImageResource(R.mipmap.ic_favoriteon);
                                    editor.putString(concurrentProfileData.getProfileId(), jsonObjFav.toString());
                                    if (favTabs) {
                                        profileDataArray.add(pd);
                                        profileDataFavArray.add(pd);
                                        ((ArrayAdapter) listView.getAdapter()).add(pd);

                                    }
//                                    editor.commit();


                                } catch (Exception e) {
                                    System.out.println("Exception" + e);
                                }
                            } else {
                                concurrentProfileData.setFav(false);
                                editor.remove(concurrentProfileData.getProfileId());
                                if (favTabs) {
                                    Object item = ((ArrayAdapter) listView.getAdapter()).getItem(position);
                                    ((ArrayAdapter) listView.getAdapter()).remove(item);
                                    profileDataArray.remove(concurrentProfileData);
                                    profileDataFavArray.remove(concurrentProfileData);
                                }
//                            prefMap.remove(concurrentProfileData.getProfileId());
                                imgFavButton.setImageResource(R.mipmap.ic_favoriteoff);
                            }
                            editor.commit();
                        }
                    });

                }
                ImageButton imgDetailsButton = (ImageButton) view.findViewById(R.id.item_details);
                imgDetailsButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        String profileId = concurrentProfileData.getProfileId();
                        String profileName = concurrentProfileData.getProfileName();
                        String profilePicture = concurrentProfileData.getImageUrl();
                        String profileType = concurrentProfileData.getProfileType();
                        Boolean isFav = concurrentProfileData.getFav();
                        detailsData.clear();
                        detailsData.put("profileId", profileId);
                        detailsData.put("profileName", profileName);
                        detailsData.put("profilePicture", profilePicture);
                        detailsData.put("isFav", isFav);
                        detailsData.put("profileType", profileType);
                        new RequestServerDetailsData().execute(profileId, profileType, "true");

                    }
                });

                ImageView imageView = (ImageView) view.findViewById(R.id.item_image);
                txtTitle.setText(concurrentProfileData.getProfileName());
                Picasso.with(this.getContext()).load(Uri.parse(concurrentProfileData.getImageUrl())).into(imageView);
            } catch (Exception e) {
                System.out.println("Exception" + e);
            }
            return view;
        }

    }


    public void buildTheFavListView() {
        SharedPreferences pref = getPreferences();
        profileDataFavArray = new ArrayList<ProfileData>();
        Map<String, String> prefList = (HashMap<String, String>) pref.getAll();
        try {
            if (null != prefList && prefList.size() > 0) {
                for (Map.Entry<String, String> entry : prefList.entrySet()) {
                    String profileId = entry.getKey();
                    String profileName = "";
                    String profileType = "";
                    String profileImage = "";
                    String data = entry.getValue();
                    JSONObject dataJson = new JSONObject(data);
                    if (null != dataJson) {
                        profileName = dataJson.get("profileName").toString();
                        profileType = dataJson.get("profileType").toString();
                        profileImage = dataJson.get("profilePicture").toString();

                    }
                    ProfileData pd = new ProfileData(profileId, profileName, profileImage, profileType, true);
                    profileDataFavArray.add(pd);
                }
            }

        } catch (Exception e) {
            System.out.println("Exception" + e);
        }


    }


    public void callToConstructView(String type) {
        Button previousButton = (Button) findViewById(R.id.previous_button);
        Button nextButton = (Button) findViewById(R.id.next_button);
        if (null != previousButton) {
            previousButton.setEnabled(false);
        }
        if (null != nextButton) {
            nextButton.setEnabled(false);
        }
        List<ProfileData> profileTypeArray = new ArrayList<ProfileData>();
        if (null != profileDataFavArray && profileDataFavArray.size() > 0) {
            for (ProfileData pd : profileDataFavArray) {
                String profileTyp = pd.getProfileType();
                if (null != type && type.equals(profileTyp)) {
                    profileTypeArray.add(pd);
                }
            }
        }
        profileDataArray.clear();
        profileDataArray.addAll(profileTypeArray);
        CustomList adapter = new CustomList(profileTypeArray);
        ListView listView = (ListView) findViewById(R.id.list_item_view);
        listView.setAdapter(adapter);


    }

    /**
     * Inner Class to get Posts Detaisl
     */
    public class RequestServerDetailsData extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
        }

        @Override
        protected String doInBackground(String... params) {
            String response = "";
            try {
                String profileId = Uri.encode(params[0]);
                String searchType = params[1];
                String isCallForDetails = params[2];
                String link = "http://sample-env.ittyk9qerj.us-west-2.elasticbeanstalk.com/FBSearch.php?profileId=" + profileId + "&searchType=" + searchType + "&isCallForDetails=" + isCallForDetails;

                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(link));
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                response = client.execute(request, responseHandler);

            } catch (Exception e) {
                System.out.println("Exception: " + e.getMessage());
            }
            return response;

        }

        @Override
        protected void onPostExecute(String result) {
            String url= buildTheDetailsData(detailsData.get("profilePicture").toString(), detailsData.get("profileName").toString(), result);
            new RequestServerDetailsAlbums().execute(url);
        }
    }

    private String buildTheDetailsData(String profilePicture, String profileName, String resp) {
        String url = "http://sample-env.ittyk9qerj.us-west-2.elasticbeanstalk.com/FBSearch.php?";
        try {
            JSONObject response = new JSONObject(resp);
            detailsDataResponse=response;
            JSONArray albumsResponse = null;
                        /*
                         To get Albums Pictures
                         */

            if (null != response && response.has("albums")) {
                JSONObject jsonAlbum = (JSONObject) response.get("albums");
                if (null != jsonAlbum && jsonAlbum.has("data")) {

                    albumsResponse = (JSONArray) jsonAlbum.get("data");
                }
            }
            int albumsRespLen = (null == albumsResponse) ? 0 : albumsResponse.length();
            String[][] albumsImagesArray = new String[5][2];
            for (int alb = 0; alb < albumsRespLen; alb++) {
                JSONObject albumJson = (JSONObject) albumsResponse.get(alb);
                int imagesLen = 0;
                JSONArray albumPics = new JSONArray();
                if (null != albumJson && albumJson.has("photos") && albumJson.getJSONObject("photos").has("data")) {
                    albumPics = (JSONArray) (albumJson.getJSONObject("photos")).get("data");
                    imagesLen = albumPics.length();
                }
                for (int pic = 0; pic < imagesLen; pic++) {
                    String eachImageId = albumPics.getJSONObject(pic).has("picture") ? (albumPics.getJSONObject(pic)).getString("id") : null;
                    albumsImagesArray[alb][pic] = eachImageId;
                    url = url + "picIdsArray[" + alb + "][" + pic + "]=" + albumsImagesArray[alb][pic] + "&";
                }

            }


            url = url + "isCallForDetails=false";
        } catch (Exception e) {
            System.out.println("Exception" + e);
        }
        return url;
    }



    /**
     * Inner Class to get Posts Detaisl
     */
    public class RequestServerDetailsAlbums extends AsyncTask<String,String,String> {

        protected void onPreExecute() {
        }

        @Override
        protected String doInBackground(String... params) {
            String response ="";
            try {
                //  String[][] imageIds=new String[5][2];
                //imageIds=params[0][0];
                //String searchType=params[1];
                //String isCallForDetails=params[2];
                String link = params[0];//http://sample-env.ittyk9qerj.us-west-2.elasticbeanstalk.com/FBSearch.php?profileId="+profileId+"&searchType="+searchType+"&isCallForDetails="+isCallForDetails;
                if(!(link.contains("picIdsArray"))){
                    return response;
                }
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(link));
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                response = client.execute(request, responseHandler);

            } catch (Exception e) {
                System.out.println("Exception: " + e.getMessage());
            }
            return response;

        }

        @Override
        protected void onPostExecute(String result) {
            Intent intent=new Intent(Results.this, ProfileDetails.class);
            intent.putExtra("profileId",detailsData.get("profileId").toString());
            intent.putExtra("profileName",detailsData.get("profileName").toString());
            intent.putExtra("profilePicture",detailsData.get("profilePicture").toString());
            intent.putExtra("isFav",(Boolean) detailsData.get("isFav"));
            intent.putExtra("isCallFromFav",isFavResults);
            intent.putExtra("profileType",detailsData.get("profileType").toString());
            intent.putExtra("detailsResponse",detailsDataResponse.toString());
            intent.putExtra("albumImages",result);
            detailsDataResponse=new JSONObject();
            startActivity(intent);
        }


    }

}
