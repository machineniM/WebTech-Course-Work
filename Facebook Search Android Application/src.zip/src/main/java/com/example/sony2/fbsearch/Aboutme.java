package com.example.sony2.fbsearch;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Aboutme extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutme);
        Intent intent = getIntent();
        if(null!=getSupportActionBar()) {
            String title = getSupportActionBar().getTitle().toString();
            getSupportActionBar().setTitle("About Me");
        }
    }
}
