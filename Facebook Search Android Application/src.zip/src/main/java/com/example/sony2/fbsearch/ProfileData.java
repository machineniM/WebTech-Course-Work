package com.example.sony2.fbsearch;

/**
 * Created by sony2 on 4/19/2017.
 */

public class ProfileData {

    public ProfileData(String id, String name, String icon, String profileType,Boolean isFav){
        setProfileName(name);
        setProfileId(id);
        setFav(isFav);
        setImageUrl(icon);
        setProfileType(profileType);
    }

    public String getProfileType() {
        return profileType;
    }

    public void setProfileType(String profileType) {
        this.profileType = profileType;
    }

    public String profileType;
    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public String getImageUrl() {
        return ImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        ImageUrl = imageUrl;
    }

    public Boolean getFav() {
        return isFav;
    }

    public void setFav(Boolean fav) {
        isFav = fav;
    }

    private String profileId;
    private String profileName;
    private String ImageUrl;
    private Boolean isFav;


}
