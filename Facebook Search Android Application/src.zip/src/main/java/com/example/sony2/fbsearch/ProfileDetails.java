package com.example.sony2.fbsearch;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProfileDetails extends AppCompatActivity implements TabLayout.OnTabSelectedListener{

    /*
    Posts Related Variables
     */
    public static List<PostObjects> profilePostsDataArray=new ArrayList<PostObjects>();
    public static JSONObject detailsResponse=new JSONObject();
    public static JSONArray albumImagesJson=new JSONArray();
    /*
    Albums related variables
     */
    //public static int lastExpandedPosition = -1;
    ExpandableListAdapter albumsListAdapter;
    ExpandableListView albumsListView;
    public static List<String> albumslistDataHeader=new ArrayList<String>();
    public static HashMap<String, List<String>> albumslistDataChild=new HashMap<>();
    public ProfileData detailProfileData;
    public Boolean isCallFromFav=false;

    private CallbackManager callbackManager;
    private LoginManager loginManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("More Details");
        int tabsLayout=R.id.details_tabs;

        TabLayout tabLayout=(TabLayout)findViewById(tabsLayout);
        if(null!=tabLayout){
            int position=tabLayout.getSelectedTabPosition();
            tabLayout.addOnTabSelectedListener(this);
        }

        /*int linearLayoutId=R.id.details_linearLayout_list;
        int relativeLayoutId=R.id.details_relativelayout_list;
        LinearLayout postLayout=(LinearLayout)findViewById(linearLayoutId);
        LinearLayout albumsLayout=(LinearLayout)findViewById(relativeLayoutId);
        albumsLayout.setVisibility(View.VISIBLE);
        postLayout.setVisibility(View.INVISIBLE);*/
        Intent intent=getIntent();
        String profileId="";
        String profileName="";
        String profilePicture="";
        String profileType="";
        Boolean isFav=false;
        String jsonDetailsData="";
        try {
            if (null != intent) {
                profileId = intent.getStringExtra("profileId");
                profileName = intent.getStringExtra("profileName");
                profilePicture = intent.getStringExtra("profilePicture");
                profileType = intent.getStringExtra("profileType");
                isFav = intent.getBooleanExtra("isFav", false);
                isCallFromFav=intent.getBooleanExtra("isCallFromFav",false);
                jsonDetailsData = intent.getStringExtra("detailsResponse");
                detailsResponse = new JSONObject(jsonDetailsData);
                String imagedata=intent.getStringExtra("albumImages");
                if(null !=imagedata &&!("".equals(imagedata)))
                {
                    albumImagesJson=new JSONArray(imagedata);
                }

                detailProfileData=new ProfileData(profileId,profileName,profilePicture,profileType,isFav);
                albumslistDataHeader.clear();
                albumslistDataChild.clear();
                if (null != detailsResponse) {
                    buildTheDetailsData(profilePicture, profileName);
                }
            }
            int textId=R.id.empty_albumsposts_text;
            TextView textView=(TextView) findViewById(textId);
            if(null!=textView && null!=albumslistDataHeader && albumslistDataHeader.size()==0){
                textView.setText("No Albums Available To Display");
            }
            callToConstructExpandableAlbumsList();
             callToConstructPostsList();
        }
        catch(Exception e){
            System.out.println("Exception"+e);
        }
    }

    public void callToConstructExpandableAlbumsList(){

        albumsListView = (ExpandableListView) findViewById(R.id.albums_list_item_view);
//        prepareListData();

        albumsListAdapter = new ExpandableListAdapter(this, albumslistDataHeader, albumslistDataChild);

        // setting list adapter
        albumsListView.setAdapter(albumsListAdapter);
        albumsListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v,
                                        int groupPosition, long id) {
                // Toast.makeText(getApplicationContext(),
                // "Group Clicked " + listDataHeader.get(groupPosition),
                // Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        // Listview Group expanded listener
        albumsListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            private int lastExpandedPosition = -1;
            @Override
            public void onGroupExpand(int groupPosition) {
                if (lastExpandedPosition != -1
                        && groupPosition != lastExpandedPosition) {
                    albumsListView.collapseGroup(lastExpandedPosition);
                }
                lastExpandedPosition = groupPosition;

               /* Toast.makeText(getApplicationContext(),
                        albumslistDataHeader.get(groupPosition) + " Expanded",
                        Toast.LENGTH_SHORT).show();*/
            }
        });

        // Listview Group collasped listener
        albumsListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
               /* Toast.makeText(getApplicationContext(),
                        albumslistDataHeader.get(groupPosition) + " Collapsed",
                        Toast.LENGTH_SHORT).show();*/

            }
        });

    }

    public void buildTheDetailsData(String profilePicture, String profileName){
        try {
            JSONObject response = detailsResponse;
            JSONArray albumsResponse = null;
                        /*
                         To get Albums Pictures
                         */

            if (null != response && response.has("albums")) {
                JSONObject jsonAlbum=(JSONObject) response.get("albums");
                if(null!=jsonAlbum && jsonAlbum.has("data")){

                    albumsResponse =(JSONArray)jsonAlbum.get("data");
                }
            }
            int albumsRespLen = (null ==albumsResponse) ? 0 : albumsResponse.length();


            albumslistDataHeader.clear();
            albumslistDataChild.clear();
            for (int i = 0; i < albumsRespLen; i++) {
                JSONObject albumJson = (JSONObject) albumsResponse.get(i);
                int imagesLen=0;
                JSONArray albumPics=new JSONArray();
                String albumName = albumJson.has("name") ? albumJson.getString("name") : "";
                albumslistDataHeader.add(albumName);
                if(null!=albumJson && albumJson.has("photos") && albumJson.getJSONObject("photos").has("data")){
                    albumPics=(JSONArray)(albumJson.getJSONObject("photos")).get("data");
                    imagesLen=albumPics.length();
                }
                List albumImagesList =new ArrayList();
                JSONArray imagePerAlbum=null;
                if  (i<albumImagesJson.length()){
                     imagePerAlbum=(JSONArray)albumImagesJson.get(i);
                }
                for (int j = 0; j < imagesLen; j++) {
                     String imageUrl = (null!= imagePerAlbum && null!= imagePerAlbum.get(j))? imagePerAlbum.get(j).toString() : "";
                     albumImagesList.add(imageUrl);
                    //albumImagesList.add("https://scontent.xx.fbcdn.net/v/t1.0-9/s720x720/18057107_10155062291165993_7318466628739263917_n.jpg?oh=71ba579ddf773850cb80f49c894e6f2d&oe=598FE7B6");
                }
                albumslistDataChild.put(albumName,albumImagesList);
            }
                        /*

                         Posts Details
                         */
            JSONArray postsResponse = null;
            profilePostsDataArray.clear();
            if (null != response && response.has("posts")) {
                JSONObject jsonPosts=(JSONObject) response.get("posts");
                if(null!=jsonPosts && jsonPosts.has("data")){

                    postsResponse =(JSONArray)jsonPosts.get("data");
                }
            }
            int postsRespLen = (null==postsResponse) ? 0 : postsResponse.length();
            //SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            //java.text.ParseException: Unparseable date: "2017-01-19T03:14:28" (at offset 10)
            for (int i = 0; i < postsRespLen; i++) {
                JSONObject postJson = (JSONObject) postsResponse.get(i);
                String message = "";
                String  postCreatedTime = null;
                String postDate="";
                if (postJson != null) {
                    String created_time=postJson.has("created_time") ?(String)postJson.get("created_time"):null;
                    if(null!=created_time) {
                        int endIndex = created_time.indexOf('T');
                        String date=created_time.substring(0, endIndex);
                        int endin=created_time.indexOf('+')>endIndex?created_time.indexOf('+'):created_time.length();
                        String time=created_time.substring(endIndex+1,endin);
                        String truncDate = created_time.substring(0, endIndex);
                        postCreatedTime =date+" "+time;// (Date) //sdf.parse(truncDate);//("YYYY-MM-DD" + " " + "HH:MM:SS");
                    }
                    if (postJson.has("message")) {
                        message = (String) postJson.get("message");
                    } else if (postJson.has("story")) {
                        message = (String) postJson.get("story");
                    }
                }
                PostObjects pd=new PostObjects(profileName,profilePicture,message,postCreatedTime);
                profilePostsDataArray.add(pd);
            }

        }
        catch(Exception e){
            System.out.println("Exception"+e);
        }
    }

    public void callToConstructPostsList(){
        try {
            CustomPostsList adapter = new CustomPostsList(profilePostsDataArray);
            ListView listView = (ListView) findViewById(R.id.posts_list_item_view);
            listView.setAdapter(adapter);
        }
        catch (Exception e){
            System.out.println("Exception"+e);
        }
    }


    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        int textId=R.id.empty_albumsposts_text;
        TextView textView=(TextView) findViewById(textId);
        String text=tab.getText().toString();
        int linearLayoutId=R.id.details_linearLayout_list;
        int relativeLayoutId=R.id.details_relativelayout_list;
        LinearLayout postLayout=(LinearLayout)findViewById(linearLayoutId);
        LinearLayout albumsLayout=(LinearLayout)findViewById(relativeLayoutId);
        if(null!=text && "albums".equals(text.toLowerCase())){
            albumsLayout.setVisibility(View.VISIBLE);
            postLayout.setVisibility(View.INVISIBLE);
            textView.setText("No Albums Available To Display");
            if(null!=albumslistDataHeader && albumslistDataHeader.size()>0){
                textView.setVisibility(View.INVISIBLE);
            }
            else{
                textView.setVisibility(View.VISIBLE);
            }
        }
        else{
            albumsLayout.setVisibility(View.INVISIBLE);
            postLayout.setVisibility(View.VISIBLE);
            textView.setText("No Posts Available To Display");
            if(null!=profilePostsDataArray&& profilePostsDataArray.size()>0){
                textView.setVisibility(View.INVISIBLE);
            }
            else{
                textView.setVisibility(View.VISIBLE);
            }
        }


    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    public class CustomPostsList extends ArrayAdapter<PostObjects> {

        public CustomPostsList(List<PostObjects> profileDataArray) {
            super(ProfileDetails.this, R.layout.layout_posts, profileDataArray);
        }

        @Override
        public View getView(final int position, View view, ViewGroup parent) {
            try {
                if (view == null) {
                    view = ProfileDetails.this.getLayoutInflater().inflate(R.layout.layout_posts, null, true);
                }
                final PostObjects concurrentPostsData =profilePostsDataArray.get(position);

                String postName=concurrentPostsData.getPostName();
                String postDate=concurrentPostsData.getPostDate();
                String postMessage=concurrentPostsData.getMessage();


                TextView txtTitle = (TextView) view.findViewById(R.id.posts_item_message);
                /*Spanned html = Html.fromHtml(
                        "<h4>"+postName+"</h4>"+postDate+"<p style=\"font-size:20px;font-family:verdana;\">"+postMessage+
                        "</p>");*/
                Spanned html = Html.fromHtml(
                       "<span style=\"font-size:21px;font-family:verdana;\"><b>"+postName+"<br>"+postDate+"</b></span><br><span style=\"font-size:21px;font-family:verdana;\">"+postMessage+"</span><br>");


                        txtTitle.setText(html);

                ImageView imageView = (ImageView) view.findViewById(R.id.posts_item_image);
                Picasso.with(this.getContext()).load(Uri.parse(concurrentPostsData.getProfilePicture())).into(imageView);
            }
            catch(Exception e){
                System.out.println("Exception"+e);
            }
            return view;
        }

    }




    public class ExpandableListAdapter extends BaseExpandableListAdapter {

        private Context _context;
        private List<String> _listDataHeader; // header titles
        // child data in format of header title, child title
        private HashMap<String, List<String>> _listDataChild;

        public ExpandableListAdapter(Context context, List<String> listDataHeader,
                                     HashMap<String, List<String>> listChildData) {
            this._context = context;
            this._listDataHeader = listDataHeader;
            this._listDataChild = listChildData;
        }

        @Override
        public Object getChild(int groupPosition, int childPosititon) {
            return this._listDataChild.get(this._listDataHeader.get(groupPosition)).get(childPosititon);
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public View getChildView(int groupPosition, final int childPosition,
                                 boolean isLastChild, View convertView, ViewGroup parent) {

            final String imageUrl1 = (String) getChild(groupPosition, childPosition);

            if (convertView == null) {
                LayoutInflater infalInflater = (LayoutInflater) this._context
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = infalInflater.inflate(R.layout.layout_details_child_item, null);
            }
            try{
            ImageView albumPic = (ImageView) convertView.findViewById(R.id.albumpic);
            Picasso.with(this._context).load(Uri.parse(imageUrl1)).into(albumPic);
            }
            catch (Exception e){
               System.out.println("Exception"+e);
            }
            return convertView;
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return this._listDataChild.get(this._listDataHeader.get(groupPosition)).size();
        }

        @Override
        public Object getGroup(int groupPosition) {
            return this._listDataHeader.get(groupPosition);
        }

        @Override
        public int getGroupCount() {
            return this._listDataHeader.size();
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded,
                                 View convertView, ViewGroup parent) {
            String albumName = (String) getGroup(groupPosition);
            if (convertView == null) {
                LayoutInflater infalInflater = (LayoutInflater) this._context
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = infalInflater.inflate(R.layout.layout_details_group_item, null);
            }

            TextView albumText = (TextView) convertView
                    .findViewById(R.id.albumName);
            albumText.setTypeface(null, Typeface.BOLD);
            albumText.setText(albumName);

            return convertView;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.profile_details, menu);
        MenuItem item= menu.getItem(0);// (MenuItem)findViewById(id);
        if(null!=detailProfileData && detailProfileData.getFav()){
            item.setTitle("Remove from Favorites");
        }
        else{
            item.setTitle("Add to Favorites");
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        if(null !=item) {
            int selectedItemId = item.getItemId();
            int favId = R.id.action_favorite;
            int fbShareId = R.id.action_fbshare;
            if (selectedItemId == favId) {
                String titleText=item.getTitle().toString();
                addRemoveFavorites(titleText,item);
                return true;
            }
            else if (selectedItemId == fbShareId) {
                faceBookShareFunction();
                return true;
            }
            else{
                Intent intent=new Intent(this,Results.class);
                intent.putExtra("isCallFromDetails",true);
                intent.putExtra("profileType",detailProfileData.getProfileType());
                String title=isCallFromFav?"Favorites":"Results";
                intent.putExtra("ToolBarTitle",title);
                startActivity(intent);
                return true;
            }
        }
       // return  super.onOptionsItemSelected(item);
        return true;
    }


    public void faceBookShareFunction(){
        List<String> permissionNeeds= Arrays.asList("publish_actions");
        FacebookSdk.sdkInitialize(getApplicationContext());
        callbackManager=CallbackManager.Factory.create();
        loginManager=LoginManager.getInstance();
        loginManager.logInWithPublishPermissions(this,permissionNeeds);
        loginManager.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                sharePhotoToFacebook();
                Toast.makeText(getApplicationContext(), "You Successfully Posted on your timeline",
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancel() {
                Toast.makeText(getApplicationContext(), "Content is not Posted on your timeline",
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(FacebookException error) {
              System.out.println("Exception"+error);
            }
        });}

      private void sharePhotoToFacebook(){
        ShareLinkContent linkContent = new ShareLinkContent.Builder()
                .setContentTitle(detailProfileData.getProfileName())
                .setContentDescription("FB SEARCH FROM USC CSCI571")
                .setRef("571 Spring 2017")
                .setImageUrl(Uri.parse(detailProfileData.getImageUrl()))
                .build();

        ShareDialog shareDialog=new ShareDialog(this);
        shareDialog.show(linkContent);

    }

    @Override
    protected void onActivityResult(int requestCode, int responseCode, Intent data)
    {
        super.onActivityResult(requestCode, responseCode, data);
        callbackManager.onActivityResult(requestCode, responseCode, data);
    }



    public void addRemoveFavorites(String title,MenuItem item){
        Boolean isFav=false;
        if(null!=title &&""!=title){
            isFav=title.contains("Add")?true:false;
            if(isFav) {
                item.setTitle("Remove From Favorites");
            }
            else{
                item.setTitle("Add to Favorites");
            }
        }
        detailProfileData.setFav(isFav);
        SharedPreferences.Editor editor = getPreferences().edit();
        Map favorites=getPreferences().getAll();
        try {
            if (isFav) {
                JSONObject jsonObjFav = new JSONObject();
                jsonObjFav.put("profileId", detailProfileData.getProfileId());
                jsonObjFav.put("profileName", detailProfileData.getProfileName());
                jsonObjFav.put("profilePicture", detailProfileData.getImageUrl());
                jsonObjFav.put("profileType", detailProfileData.getProfileType());
                editor.putString(detailProfileData.getProfileId(), jsonObjFav.toString());
                Toast.makeText(getApplicationContext(), "Added to Favorites",
                        Toast.LENGTH_SHORT).show();
            }
            else {
                editor.remove(detailProfileData.getProfileId());
                Toast.makeText(getApplicationContext(), "Removed from Favorites",
                        Toast.LENGTH_SHORT).show();
            }
            editor.commit();
        }
        catch (Exception e){
            System.out.println("Exception"+e);
        }

    }

    public SharedPreferences getPreferences() {
        Context context = this.getApplicationContext();
        SharedPreferences sharedPref = this.getSharedPreferences("LocalStorageFav", context.MODE_PRIVATE);
        return sharedPref;
    }


}
