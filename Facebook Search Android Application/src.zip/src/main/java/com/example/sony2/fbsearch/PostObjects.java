package com.example.sony2.fbsearch;

import java.util.Date;

/**
 * Created by sony2 on 4/23/2017.
 */

public class PostObjects {
    PostObjects(String profileName,String profilePicture,String message,String postCreatedTime){
        setMessage(message);
        setPostDate(postCreatedTime);
        setPostName(profileName);
        setProfilePicture(profilePicture);
    }

    public String getPostDate() {
        return postDate;
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String postDate;
    public String postName;
    public String profilePicture;
    public String Message;
}
