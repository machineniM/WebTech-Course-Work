package com.example.sony2.fbsearch;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import org.apache.http.client.ResponseHandler;
import org.apache.http.impl.client.BasicResponseHandler;
import org.json.JSONObject;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;



public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    public static int typeChecker=0;
    public static HashMap<String,JSONObject> jsonProfileArrayObjects=new HashMap<String, JSONObject>();
    public static String last_Acc_Item="";
    public static String searchString="";
    public static String output="";

    public String getSearchString() {
        return searchString;
    }

    public void setSearchString(String searchString) {
        this.searchString = searchString;
    }

    public String getLast_Acc_Item() {
        return last_Acc_Item;
    }

    public void setLast_Acc_Item(String last_Acc_Item) {
        this.last_Acc_Item = last_Acc_Item;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
      //  navigationView.getMenu().getItem(0).setChecked(true);

         if(null!=getLast_Acc_Item()&&"nav_favorites"==getLast_Acc_Item()){
            MenuItem navFavItem = (MenuItem) findViewById(R.id.nav_favorites);
             onNavigationItemSelected(navFavItem);
             navigationView.getMenu().getItem(1).setChecked(true);

        }
        /*else  if(null!=getLast_Acc_Item()&&"nav_home"==getLast_Acc_Item()) {
             navigationView.getMenu().getItem(0).setChecked(true);
         }*/
         else{
             navigationView.getMenu().getItem(0).setChecked(true);
         }
        EditText editText = (EditText) findViewById(R.id.editText);
        if(null!=editText) {
            String setEditText=getSearchString();
            editText.setText(setEditText);
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        if(null==item){
            String itemSelected=getLast_Acc_Item();
            if (null!=itemSelected&&"nav_home"==itemSelected) {
                setLast_Acc_Item("nav_home");

            } else if (null!=itemSelected&&"nav_favorites"==itemSelected) {
                setLast_Acc_Item("nav_favorites");
                if (null != getSupportActionBar()) {
                    String title = getSupportActionBar().getTitle().toString();
                  //  getSupportActionBar().setTitle("Favorites");
                }
            }


        }
        else {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                setLast_Acc_Item("nav_home");
                int searchLayout = R.id.search_Layout;
                View search_Layout_View = (View) findViewById(searchLayout);
                if (null != getSupportActionBar()) {
                    String title = getSupportActionBar().getTitle().toString();
                    getSupportActionBar().setTitle("Search on FB");
                }
                // Handle the favorites action
            } else if (id == R.id.nav_favorites) {
                setLast_Acc_Item("nav_favorites");
                if (null != getSupportActionBar()) {
                    String title = getSupportActionBar().getTitle().toString();
                    getSupportActionBar().setTitle("Favorites");
                }
                Intent intent=new Intent(this,Results.class);
                intent.putExtra("ToolBarTitle","Favorites");
                intent.putExtra("profileType","user");
               startActivity(intent);
                if (null != getSupportActionBar()) {
                    String title = getSupportActionBar().getTitle().toString();
                    getSupportActionBar().setTitle("Favorites");
                }
            } else if (id == R.id.nav_about_me) {
                Intent intent = new Intent(this, Aboutme.class);
                startActivity(intent);
            }
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;

    }


    public void onClearClick(View view){
        int id=R.id.editText;
        EditText editText = (EditText) findViewById(id);
        if(null!=editText) {
            editText.setText("");
        }
        setSearchString("");
    }

    public void onSearchClick(View view) {
        int id=R.id.editText;
        EditText editText = (EditText) findViewById(id);
        String text="";
        if(null!=editText) {
            text = (editText.getText()).toString();
        }
        if(null!=text && ((text.trim()).length()>0)) {
            /*Initate the Http call**/
            String url = "https://hw7wtmm.appspot.com/?keyword="+text+"&searchtype=user";
            setSearchString(text);
            //String profileTypeArray[]=new String[5];
            String profileTypeArray[]={"user", "page", "event", "place", "group"};
            for(String profileType : profileTypeArray) {
                new RequestServerData().execute(text, profileType);
            }
        }
        else{
            Toast.makeText(getApplicationContext(),"Please Provide the Input and Click on Search",  Toast.LENGTH_SHORT).show();
        }
    }

    /*inner class*/
    public class RequestServerData  extends AsyncTask<String, String, String> {

        protected void onPreExecute(){
        }

        @Override
        protected String doInBackground(String... params) {
               try{
                    String keyWord= Uri.encode(params[0]);
                    String type=params[1];
                    String link = "http://sample-env.ittyk9qerj.us-west-2.elasticbeanstalk.com/FBSearch.php?keyword="+keyWord+"&searchtype="+type;
                    if("place"==type){
                        link=link+"&geoLatitude=34.019472&geoLongitude=-118.289281";
                    }

                    URL url = new URL(link);
                    HttpClient client = new DefaultHttpClient();
                    HttpGet request = new HttpGet();
                    request.setURI(new URI(link));
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    String response = client.execute(request,responseHandler);
                    JSONObject json = new JSONObject(response);
                    typeChecker++;
                    jsonProfileArrayObjects.put(type,json);

                   if(typeChecker>4) {
                       Intent intent = new Intent(MainActivity.this, Results.class);
                       intent.putExtra("SearchKeyWord", params[0]);
                       intent.putExtra("ToolBarTitle","Results");
                       intent.putExtra("profileType","user");
                       for (Map.Entry<String, JSONObject> entry  :jsonProfileArrayObjects.entrySet()) {
                           intent.putExtra(entry.getKey(),entry.getValue().toString());
                       }
                       startActivity(intent);
                       typeChecker=0;
                   }
                   return "";

                } catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

        }

        @Override
        protected void onPostExecute(String result){

        }
    }


}
